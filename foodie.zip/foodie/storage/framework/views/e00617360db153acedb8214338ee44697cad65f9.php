<?php $__env->startSection('content'); ?>


<body data-gr-c-s-loaded="true">



  <div class="col-md-9 col-lg-9" style="float:left;">
     <div class="jumbotron text-center">
      <h1 class="display-4"><?php echo e($recipe->name); ?></h1>
     </div>

    
        <div class="card mb-4 shadow-sm">
          <div class="card-header">
            <h4 class="my-0 font-weight-normal"><?php echo e($recipe->description); ?></h4>
          </div>
         </div>


      </div>

      <div class="col-sm-3 col-md-3 col-lg-3" style="float: right; padding-top: 4%">
          
          <div class="sidebar-module">
            <h4>Actions</h4>
            <ol class="list-unstyled">
              <li><a href="/recipes/<?php echo e($recipe->id); ?>/edit">Edit</a></li>
              <li><a href="/recipes" onclick="
                  var result = confirm('Are you sure you wish to delete this recipe?');
                      if( result ){
                              event.preventDefault();
                              document.getElementById('delete-form').submit();
                      }
                          ">Delete</a>

              <form id="delete-form" action="<?php echo e(route('recipes.destroy',[$recipe->id])); ?>" 
                method="POST" style="display: none;">
                        <input type="hidden" name="_method" value="delete">
                        <?php echo e(csrf_field()); ?>

              </form>
  
              </li>
               <li><a href="/recipes">My recipes</a></li>

              <li><a href="/recipes/create">Create new recipe</a></li>
            
            <br/>
          </ol>
        </div>
      </div>
    </div>

   
  

</body>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>