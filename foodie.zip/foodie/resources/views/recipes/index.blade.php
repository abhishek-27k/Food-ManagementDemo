
@extends('layouts.app')

@section('content')

<div class="container" style="">

  <li class="list-group-item active" > Recipes  </li>    
    <ul class="list-group">

      @foreach($recipes as $recipe)
      <li class="list-group-item"><a href= "/recipes/{{$recipe->id}}"> {{$recipe->name }} </li>
      @endforeach
    </ul>
    <br>
    <div style="padding-left: 22%">
    	<button class="btn btn-primary btn-lg " style="width: 550px; text-align: center; " ><a href="/recipes/create" style="color: white;">Create new recipe</a> </button>    
</div>  







@endsection